#ifndef __input__
#define __input__

typedef struct _boardRules boardRules;
void readInputFile(FILE *fp, boardRules *brp, char *output);

#endif
