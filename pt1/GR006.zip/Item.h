#ifndef __Item__
#define __Item__

typedef int Item;

#endif 
