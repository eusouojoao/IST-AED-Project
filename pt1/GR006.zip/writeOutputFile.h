#ifndef __writeOutputFile__
#define __writeOutputFile__

void write2outputFile (char *output, int to_print);

#endif
