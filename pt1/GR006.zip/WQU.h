#ifndef __WQU__
#define __WQU__

void WQU(int *id, int *sz, int p, int q);
void connectivityAdjacentWQU(int *id, int *sz, int *board, int tile, int n_Lines, int n_Col);
int sameRoomWQU(int *board, int n_Lines, int n_Col, int p1, int p2);

#endif 
