#ifndef __algoritmo__
#define __algoritmo__

void algoritmo (Graph *G);
void writeSolution(char *output, Graph *G, int tesouroRoom, int colunas, bool first, bool experimental);

#endif /* __algoritmo__ */
